import cx_Oracle
import pandas as pd

def getOracleData(ip,
                  port,
                  DBname,
                  userName,
                  password,
                  statement):
    dsn_tns = cx_Oracle.makedsn(ip, port, DBname)
    conn = cx_Oracle.connect(userName, password, dsn_tns,encoding='UTF-8')
    df_ora = pd.read_sql(statement, con=conn)
    conn.close()
    return df_ora

def selectSeq(ip,
              port,
              DBname,
              userName,
              password,
              seqName):

    dsn_tns = cx_Oracle.makedsn(ip, port, DBname)
    conn = cx_Oracle.connect(userName, password, dsn_tns,encoding='UTF-8')

    sql = 'SELECT '+ seqName +'.NEXTVAL COL FROM DUAL'
    df_ora = int(pd.read_sql(sql, con=conn).loc[0, 'COL'])
    conn.close()
    return df_ora

def insertToLog(ip,
                port,
                DBname,
                userName,
                password,
                sub_seq_key,
                process_key,
                log_type_key,
                log_name,
                log_result,
                log_message,
                log_user,
                last_updated_by,
                run_at_server_name):
    dsn_tns = cx_Oracle.makedsn(ip, port, DBname)
    conn = cx_Oracle.connect(userName, password, dsn_tns,encoding='UTF-8')

    cursInsert = conn.cursor()
    input_sub_log_key = sub_seq_key
    input_process_key = process_key
    input_log_type_key = log_type_key
    input_log_name = log_name
    input_log_result = log_result
    input_log_message = log_message
    input_log_user = log_user
    input_last_updated_by = last_updated_by
    input_run_at_server_name = run_at_server_name

    insert_values = 'INSERT INTO \
                        REVENUE.RPA_FT_LOG(sub_seq_key, \
                                             process_key,\
                                             log_type_key,\
                                             log_name,\
                                             log_result,\
                                             log_message,\
                                             log_user,\
                                             last_updated_by,\
                                             last_updated_date, \
                                             run_at_server_name)\
                            VALUES(:sub_seq_key, \
                                   :process_key,\
                                   :log_type_key,\
                                   :log_name,\
                                   :log_result,\
                                   :log_message,\
                                   :log_user,\
                                   :last_updated_by,\
                                    sysdate,\
                                   :run_at_server_name)'

    cursInsert.execute(insert_values,
                       sub_seq_key=int(input_sub_log_key),
                       process_key=int(input_process_key),
                       log_type_key=input_log_type_key,
                       log_name=input_log_name,
                       log_result=input_log_result,
                       log_message=input_log_message,
                       log_user=input_log_user,
                       last_updated_by=input_last_updated_by,
                       run_at_server_name=input_run_at_server_name)

    conn.commit()
    cursInsert.close()