### **寫log到資料庫**
資料庫連線設定在`Setting\__init__.py`中
<br />
先針對要新增的Process，在`RPA_DT_PROCESS`Table裡Insert（Insert完記得Commit）
<br />
例如：
<br />
`INSERT INTO RPA_DT_PROCESS(PROCESS_NAME,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,ACTIVE_FLAG)
VALUES('Sample','peter.kt.chen',SYSDATE,'peter.kt.chen','Y');`
<br />
接著請參考`Samples\write_log_to_db.py`的語法，
在自己的Process py檔中加入相對應Function
