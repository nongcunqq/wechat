from Functions.DB import *
# region 測試環境
# DB_IP = '10.62.163.234'
# DB_PORT = '1560'
# DB_NAME = 'CESBC'
# DB_USERNAME = 'REVENUE'
# DB_PASSWORD = 'REVENUE'
# endregion

# region 正式環境
DB_IP = '10.62.170.214'
DB_PORT = '1560'
DB_NAME = 'CESBC'
DB_USERNAME = 'REVENUE'
DB_PASSWORD = 'REVENUE'
# endregion

# region log type variables
LOG_TYPE_LOG_NAME = 'LOG'
LOG_TYPE_FILE_NAME = 'FILE'
LOG_TYPE_EXCEPTION_NAME = 'EXCEPTION'

LOG_TYPE_LOG_KEY = int(getOracleData(DB_IP,
                                DB_PORT,
                                DB_NAME,
                                DB_USERNAME,
                                DB_PASSWORD,
                                'SELECT LOG_TYPE_KEY '
                                'FROM REVENUE.RPA_DT_LOG_TYPE '
                                "WHERE LOG_TYPE_NAME = '" + str(LOG_TYPE_LOG_NAME) + "'")['LOG_TYPE_KEY'][0])
LOG_TYPE_FILE_KEY = int(getOracleData(DB_IP,
                                DB_PORT,
                                DB_NAME,
                                DB_USERNAME,
                                DB_PASSWORD,
                                'SELECT LOG_TYPE_KEY '
                                'FROM REVENUE.RPA_DT_LOG_TYPE '
                                "WHERE LOG_TYPE_NAME = '" + str(LOG_TYPE_FILE_NAME) + "'")['LOG_TYPE_KEY'][0])
LOG_TYPE_EXCEPTION_KEY = int(getOracleData(DB_IP,
                                DB_PORT,
                                DB_NAME,
                                DB_USERNAME,
                                DB_PASSWORD,
                                'SELECT LOG_TYPE_KEY '
                                'FROM REVENUE.RPA_DT_LOG_TYPE '
                                "WHERE LOG_TYPE_NAME = '" + str(LOG_TYPE_EXCEPTION_NAME) + "'")['LOG_TYPE_KEY'][0])
# endregion
# region log result variables
LOG_RESULT_SUCCESS = 'SUCCESS'
LOG_RESULT_FAIL = 'FAIL'
# endregion

# region mail recipient type key
MAIL_RECIPIENT_TYPE_TO_KEY = 1
MAIL_RECIPIENT_TYPE_CC_KEY = 2
MAIL_RECIPIENT_TYPE_BCC_KEY = 3
# endregion

SMTP_IP = '10.134.28.95'  # 'smtp.gmail.com'
SMTP_PORT = 25  # 587

EMAIL_FROM = 'ces-it-rpa05@fii-foxconn.com'
EMAIL_PASSWORD = '82767630'

SMTP_CONTENT_TYPE_HTML = 'html'
SMTP_CONTENT_TYPE_TEXT = 'text'