from Functions.DB import *
from Functions.Log import *
from Setting import *
import socket


try:

    PROCESS_NAME = 'Sample'
    # 取得PROCESS_KEY
    PROCESS_KEY = int(getOracleData(DB_IP,
                                    DB_PORT,
                                    DB_NAME,
                                    DB_USERNAME,
                                    DB_PASSWORD,
                                    'SELECT PROCESS_KEY '
                                    'FROM REVENUE.RPA_DT_PROCESS '
                                    "WHERE PROCESS_NAME = '" + str(PROCESS_NAME) + "'")['PROCESS_KEY'][0])
    print('PROCESS_KEY = ' + str(PROCESS_KEY))

    CURRENT_SEVER_NAME = socket.gethostname()

    # 取得SUB_SEQ_KEY
    SUB_SEQ_KEY = selectSeq(DB_IP, DB_PORT, DB_NAME, DB_USERNAME, DB_PASSWORD,
                            'REVENUE.RPA_DT_SUB_SEQ_KEY_S')

    # 寫入Process Start Log
    insertToLog(ip=DB_IP,
                port=DB_PORT,
                DBname=DB_NAME,
                userName=DB_USERNAME,
                password=DB_PASSWORD,
                sub_seq_key=SUB_SEQ_KEY,
                process_key=PROCESS_KEY,
                log_type_key=LOG_TYPE_LOG_KEY,
                log_name='Process Start',
                log_result=LOG_RESULT_SUCCESS,
                log_message='Process Start',
                log_user='',
                last_updated_by='rpa',
                run_at_server_name=CURRENT_SEVER_NAME
                )
    temp = 1 / 0
    # 寫入Process End Log
    insertToLog(ip=DB_IP,
                port=DB_PORT,
                DBname=DB_NAME,
                userName=DB_USERNAME,
                password=DB_PASSWORD,
                sub_seq_key=SUB_SEQ_KEY,
                process_key=PROCESS_KEY,
                log_type_key=LOG_TYPE_LOG_KEY,
                log_name='Process End',
                log_result=LOG_RESULT_SUCCESS,
                log_message='Process End',
                log_user='',
                last_updated_by='rpa',
                run_at_server_name=CURRENT_SEVER_NAME
                )
except:
    error_message = get_exception_message()
    # 寫入Process End Log
    insertToLog(ip=DB_IP,
                port=DB_PORT,
                DBname=DB_NAME,
                userName=DB_USERNAME,
                password=DB_PASSWORD,
                sub_seq_key=SUB_SEQ_KEY,
                process_key=PROCESS_KEY,
                log_type_key=LOG_TYPE_EXCEPTION_KEY,
                log_name='Raise an error',
                log_result=LOG_RESULT_FAIL,
                log_message=error_message,
                log_user='',
                last_updated_by='rpa',
                run_at_server_name=CURRENT_SEVER_NAME
                )
