from time import sleep
from PIL import Image
from selenium import webdriver
import datetime
import os
import logging
import pyautogui


Date = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y-%m-%d")


class Logger(object):
    def __init__(self, logger):
        self.logger = logging.getLogger(logger)
        self.logger.setLevel(logging.DEBUG)
        log_name = r'C:\Users\Administrator\Desktop\Email_%s.log' % Date
        fh = logging.FileHandler(log_name)
        fh.setLevel(logging.INFO)
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        fh.setFormatter(formatter)
        ch.setFormatter(formatter)
        self.logger.addHandler(fh)
        self.logger.addHandler(ch)

    def getlog(self):
        return self.logger


mylogger = Logger(logger='fidm').getlog()


def CESBGRevenueReport():

    option = webdriver.ChromeOptions()
    option.add_experimental_option("excludeSwitches", ['enable-automation'])
    option.add_experimental_option('useAutomationExtension', False)

    driver = webdriver.Chrome(chrome_options=option)
    driver.maximize_window()
    driver.get(
        'http://fbcbi.efoxconn.com/decision/view/report?viewlet=%252FRevenue_PRD%252FRevenue_Reports_SBG_FIDM.frm&__parameters__=%257B%2522__pi__%2522%253Atrue%252C%2522%2524SBG%2522%253A%2522%2524%2524%2524%2522%257D&_=1600147537974')
    sleep(12)

    pyautogui.press('F11')
    sleep(10)

    # 截图
    pyautogui.hotkey('ctrl', 'b')
    sleep(2)
    pyautogui.moveTo(315, 150)
    sleep(2)
    pyautogui.click()
    sleep(20)

    # 总收入
    T1 = driver.find_element_by_xpath(
        '/html/body/div[1]/div[2]/div[2]/div/div/div/div[1]/div/div/div/table/tbody/tr[2]/td[4]').text

    # 速度表左
    T2 = driver.find_element_by_css_selector("g.vancharts-series-0.gauge > g > g > text").text

    # 速度表右
    T3 = driver.find_elements_by_css_selector("g.vancharts-series-0.gauge > g > g > text")[1].text

    # DOD
    T4 = driver.find_element_by_xpath(
        '/html/body/div[1]/div[2]/div[10]/div[1]/div/div/div[1]/div/div/div/table/tbody/tr[11]/td[14]/div').text

    # Bi时间，当前时间 - 1
    Date = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y-%m-%d")

    # data
    gist = 'Up to %s FIDM Billing %sM, VS.CEO target Hit rate %s, VS.F/C Hit rate %s, DOD %sM.' \
           % (Date, T1, T2, T3, T4)

    # 写入文件
    file_handle = open(r'C:\PythonProject\FIDM-BCC\text\%s.txt' % Date, mode='w')
    file_handle.write(gist)
    file_handle.close()
    mylogger.info('Y_text')

    driver.quit()

    im = Image.open(r"C:\Users\Administrator\Desktop\BI.png")
    imBackground = im.resize((1280, 1904))
    imBackground.save(r"C:\Users\Administrator\Pictures\FIDM_Png\%s.png" % Date)

    os.remove(r'C:\Users\Administrator\Desktop\BI.png')


CESBGRevenueReport()
