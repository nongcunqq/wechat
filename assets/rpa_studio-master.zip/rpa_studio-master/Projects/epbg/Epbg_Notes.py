import win32api, win32gui, win32con, win32ui, subprocess, sys, os
import pyautogui
import time
import datetime
import logging

time.sleep(5)

Date = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y-%m-%d")
Notes_pwd = '82767630'


class Logger(object):
    def __init__(self, logger):
        self.logger = logging.getLogger(logger)
        self.logger.setLevel(logging.DEBUG)
        log_name = r'C:\Users\Administrator\Desktop\Email_%s.log' % Date
        fh = logging.FileHandler(log_name)
        fh.setLevel(logging.INFO)
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        fh.setFormatter(formatter)
        ch.setFormatter(formatter)
        self.logger.addHandler(fh)
        self.logger.addHandler(ch)

    def getlog(self):
        return self.logger


mylogger = Logger(logger='epbg').getlog()


class SendMail(object):
    def epbg(self):

        Notes_Exe = r"C:\Program Files (x86)\IBM\Notes\notes.exe"
        subprocess.Popen(Notes_Exe)
        time.sleep(10)

        # 密码 & 确认
        hwnd = win32gui.FindWindow(None, "IBM Notes")
        flt = win32gui.FindWindowEx(hwnd, None, 'IRIS.password', None)
        win32gui.SendMessage(flt, win32con.WM_SETTEXT, None, Notes_pwd)
        time.sleep(3)
        butt = win32gui.FindWindowEx(hwnd, None, 'button', None)
        win32gui.PostMessage(butt, win32con.WM_KEYDOWN, win32con.VK_RETURN, 0)
        win32gui.SendMessage(butt, win32con.WM_KEYDOWN, win32con.VK_RETURN, 0)
        time.sleep(10)

        # 快捷键 - 打开新信件
        pyautogui.moveTo(371, 17)
        time.sleep(2)
        pyautogui.click()
        pyautogui.hotkey('ctrl', 'm')

        # 复制TO
        time.sleep(15)
        pyautogui.hotkey('win', 'r')
        time.sleep(1)
        pyautogui.typewrite(r'C:\PythonProject\EPBG-BCC\text\TO.txt')
        pyautogui.press('enter')
        time.sleep(1)
        pyautogui.hotkey('ctrl', 'a')
        time.sleep(1)
        pyautogui.hotkey('ctrl', 'c')
        time.sleep(1)
        pyautogui.hotkey('alt', 'F4')

        # 输入TO
        time.sleep(1)
        pyautogui.moveTo(315, 13)
        time.sleep(1)
        pyautogui.click()
        time.sleep(1)
        pyautogui.hotkey('ctrl', 'v')
        time.sleep(1)
        pyautogui.press('tab')
        pyautogui.press('tab')

        # 复制CC
        time.sleep(1)
        pyautogui.hotkey('win', 'r')
        time.sleep(1)
        pyautogui.typewrite(r'C:\PythonProject\EPBG-BCC\text\CC.txt')
        pyautogui.press('enter')
        time.sleep(1)
        pyautogui.hotkey('ctrl', 'a')
        time.sleep(1)
        pyautogui.hotkey('ctrl', 'c')
        time.sleep(1)
        pyautogui.hotkey('alt', 'F4')

        # 输入CC
        time.sleep(1)
        pyautogui.moveTo(315, 13)
        time.sleep(1)
        pyautogui.click()
        time.sleep(1)
        pyautogui.hotkey('ctrl', 'v')
        time.sleep(1)
        pyautogui.press('tab')

        # 复制BCC
        time.sleep(1)
        pyautogui.hotkey('win', 'r')
        time.sleep(1)
        pyautogui.typewrite(r'C:\PythonProject\EPBG-BCC\text\BCC.txt')
        pyautogui.press('enter')
        time.sleep(1)
        pyautogui.hotkey('ctrl', 'a')
        time.sleep(1)
        pyautogui.hotkey('ctrl', 'c')
        time.sleep(1)
        pyautogui.hotkey('alt', 'F4')

        # 输入BCC
        time.sleep(1)
        pyautogui.moveTo(315, 15)
        time.sleep(1)
        pyautogui.click()
        time.sleep(1)
        pyautogui.hotkey('ctrl', 'v')
        time.sleep(1)
        pyautogui.press('tab')

        # 复制主旨
        time.sleep(1)
        pyautogui.hotkey('win', 'r')
        time.sleep(1)
        pyautogui.typewrite(r'C:\PythonProject\EPBG-BCC\text\%s.txt' % Date)
        pyautogui.press('enter')
        time.sleep(1)
        pyautogui.hotkey('ctrl', 'a')
        time.sleep(1)
        pyautogui.hotkey('ctrl', 'c')
        time.sleep(1)
        pyautogui.hotkey('alt', 'F4')

        # 输入主旨
        time.sleep(1)
        pyautogui.moveTo(315, 13)
        time.sleep(1)
        pyautogui.click()
        time.sleep(1)
        pyautogui.hotkey('ctrl', 'v')
        time.sleep(1)

        # 切换到内容正确位置
        pyautogui.press('tab')
        time.sleep(1)
        pyautogui.hotkey('shift', 'tab')
        time.sleep(1)
        pyautogui.press('tab')

        # 复制内容
        time.sleep(1)
        pyautogui.hotkey('win', 'r')
        time.sleep(1)
        pyautogui.typewrite(r'C:\PythonProject\EPBG-BCC\text\content.txt')
        pyautogui.press('enter')
        time.sleep(1)
        pyautogui.hotkey('ctrl', 'a')
        time.sleep(1)
        pyautogui.hotkey('ctrl', 'c')
        time.sleep(1)
        pyautogui.hotkey('alt', 'F4')

        # 输入内容
        time.sleep(1)
        pyautogui.moveTo(315, 13)
        time.sleep(1)
        pyautogui.click()
        time.sleep(1)
        pyautogui.hotkey('ctrl', 'v')
        time.sleep(1)
        pyautogui.press('enter')

        # 切换到内容当中正确图片位置
        time.sleep(2)
        for i in range(5):
            pyautogui.press('up')

        # 移动坐标 - import位置
        time.sleep(2)
        pyautogui.moveTo(980, 119)
        time.sleep(2)
        pyautogui.click()

        # 移动坐标 - (点击图片)
        time.sleep(2)
        pyautogui.moveTo(77, 248)
        pyautogui.click(clicks=2, interval=0.1)
        time.sleep(1)
        pyautogui.moveTo(193, 198)
        time.sleep(1)
        pyautogui.click(clicks=2, interval=0.1)
        time.sleep(1)
        pyautogui.moveTo(380, 160)
        time.sleep(1)
        pyautogui.click(clicks=2, interval=0.1)
        time.sleep(1)
        pyautogui.moveTo(279, 160)
        time.sleep(1)
        pyautogui.click(clicks=2, interval=0.1)
        time.sleep(1)

        # 移动坐标 - 点击发送
        time.sleep(2)
        pyautogui.moveTo(32, 151)
        time.sleep(2)
        pyautogui.click()
        mylogger.info('Y_sendmail')

        # 关闭notes
        time.sleep(15)
        pyautogui.moveTo(315, 13)
        time.sleep(2)
        pyautogui.click()
        time.sleep(2)
        pyautogui.hotkey('alt', 'F4')
        time.sleep(2)

        os.remove(r"C:\Users\Administrator\Pictures\Epbg_Png\%s.png" % Date)
        os.remove(r"C:\PythonProject\EPBG-BCC\text\%s.txt" % Date)


testlog = SendMail()

testlog.epbg()


