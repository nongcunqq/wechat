from time import sleep
from selenium import webdriver
import datetime

Date = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y-%m-%d")


def CESBGDOD():
    option = webdriver.ChromeOptions()
    option.add_experimental_option("excludeSwitches", ['enable-automation'])
    option.add_experimental_option('useAutomationExtension', False)
    driver = webdriver.Chrome(chrome_options=option)
    driver.maximize_window()
    driver.get(
        'http://fbcbi.efoxconn.com/decision/view/report?viewlet=%252FRevenue_PRD%252FRevenue_Reports_BG.frm&__parameters__=%257B%2522__pi__%2522%253Atrue%257D&_=1598067216116')
    sleep(12)

    # 循环遍历DOD
    All_DOD = driver.find_element_by_xpath(
        "/html/body/div[1]/div[2]/div[9]/div[1]/div/div/div[1]/div/div/div/table/tbody").text

    dod = open(r'C:\PythonProject\CESBG-BCC\text\%s_dod.txt' % Date, mode='w')
    dod.write(All_DOD)
    driver.quit()


CESBGDOD()

