from time import sleep
from PIL import Image
from selenium import webdriver
import datetime
import os
import logging
import pyautogui
import time, datetime
import calendar

Date = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y-%m-%d")


class Logger(object):
    def __init__(self, logger):
        self.logger = logging.getLogger(logger)
        self.logger.setLevel(logging.DEBUG)
        log_name = r'C:\Users\Administrator\Desktop\Email_%s.log' % Date
        fh = logging.FileHandler(log_name)
        fh.setLevel(logging.INFO)
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        fh.setFormatter(formatter)
        ch.setFormatter(formatter)
        self.logger.addHandler(fh)
        self.logger.addHandler(ch)

    def getlog(self):
        return self.logger


mylogger = Logger(logger='cesbg').getlog()


def CESBGRevenueReport():
    option = webdriver.ChromeOptions()
    option.add_experimental_option("excludeSwitches", ['enable-automation'])
    option.add_experimental_option('useAutomationExtension', False)
    driver = webdriver.Chrome(chrome_options=option)
    driver.maximize_window()
    driver.get(
        'http://fbcbi.efoxconn.com/decision/view/report?viewlet=%252FRevenue_PRD%252FRevenue_Reports_BG.frm&__parameters__=%257B%2522__pi__%2522%253Atrue%257D&_=1598067216116')
    sleep(12)

    pyautogui.press('F11')
    sleep(12)

    pyautogui.hotkey('ctrl', 'b')
    sleep(2)
    pyautogui.moveTo(315, 150)
    sleep(2)
    pyautogui.click()
    sleep(20)

    # 总收入
    T1 = driver.find_element_by_xpath(
        '/html/body/div[1]/div[2]/div[2]/div/div/div/div[1]/div/div/div/table/tbody/tr[2]/td[4]').text

    # 速度表左
    T2 = driver.find_element_by_css_selector("g.vancharts-series-0.gauge > g > g > text").text

    # 速度表右
    T3 = driver.find_elements_by_css_selector("g.vancharts-series-0.gauge > g > g > text")[1].text

    # print("-------------------最后一列------------------------")

    # 创建空字典，临时添加 >=100，所有数据放入字典，排序，删除0，拿到最小3个元素。
    VSCEO_dic = {}

    # 获取第一行JUNCEO
    JUN_yi = driver.find_element_by_xpath(
        "/html/body/div[1]/div[2]/div[8]/div[1]/div/div/div[1]/div/div/div/table/tbody/tr[2]/td[14]/div").text

    # 转为int 删除
    JUN_yi = int(JUN_yi.replace(",", ''))

    # 判断第一行JUNCEO
    if JUN_yi >= 100:

        # 拿到最后一列的第一个元素
        VSCEO_T5 = driver.find_element_by_xpath(
            "/html/body/div[1]/div[2]/div[8]/div[1]/div/div/div[1]/div/div/div/table/tbody/tr[2]/td[15]/div").text

        # str删除最后一个字符
        VSCEO_T5 = VSCEO_T5[:-1]

        # 拿到第一行的name
        VSCEO_name = driver.find_element_by_xpath(
            "/html/body/div[1]/div[2]/div[8]/div[1]/div/div/div[1]/div/div/div/table/tbody/tr[2]/td[2]/div").text

        # 添加到字典，去除%
        for i in VSCEO_T5.split("%"):
            VSCEO_dic[VSCEO_name] = int(i)
    else:
        # print("JUNCEO小于100，不得把数据添加到字典")
        pass

    # 循环所有数据
    for VSCEO_all in range(3, 25):

        # 遍历JUN_All每一个数据
        JUN_All = driver.find_element_by_xpath(
            "/html/body/div[1]/div[2]/div[8]/div[1]/div/div/div[1]/div/div/div/table/tbody/tr[%s]/td[13]/div" % VSCEO_all).text

        # JUN_All转为int删除
        JUN_All = int(JUN_All.replace(",", ''))

        if JUN_All >= 100:

            # 遍历每一个数据
            VSCEO_AllXpath = driver.find_element_by_xpath(
                "/html/body/div[1]/div[2]/div[8]/div[1]/div/div/div[1]/div/div/div/table/tbody/tr[%s]/td[14]/div" % VSCEO_all).text

            # 遍历每一个数据,去除%
            VSCEO_AllXpath = VSCEO_AllXpath[:-1]

            # 遍历每一个name
            VSCEO_Allname = driver.find_element_by_xpath(
                "/html/body/div[1]/div[2]/div[8]/div[1]/div/div/div[1]/div/div/div/table/tbody/tr[%s]/td[1]/div" % VSCEO_all).text

            # 遍历每一个数据,去除%
            for VSCEO_split in VSCEO_AllXpath.split("%"):
                VSCEO_dic[VSCEO_Allname] = int(VSCEO_split)

    # VSCEO 排序
    VSCEO_Sort = sorted(VSCEO_dic.items(), key=lambda x: x[1], reverse=False)

    # 判断所有字典value中是否存在 0，有则删除。
    for value in list(VSCEO_dic.values()):
        if value == 0:
            del VSCEO_Sort[value]

    # print(VSCEO_Sort)

    # VS.CEO:最小的3个元素
    # print(f'VS.CEO:最小的3个元素：{VSCEO_Sort[:3]}')

    # # 最小的3个元素，转换输出样式
    Minimum = '%s %s%%, %s %s%%, %s %s%%' % (
        VSCEO_Sort[0][0], VSCEO_Sort[0][1], VSCEO_Sort[1][0], VSCEO_Sort[1][1], VSCEO_Sort[2][0], VSCEO_Sort[2][1])

    # print(Minimum)
    #
    # print("-------------------倒数第四列------------------------")

    # 创建空字典 VSFC_dic
    VSFC_dic = {}

    # 获取第一行JUNCEO
    WKFC = driver.find_element_by_xpath(
        "/html/body/div[1]/div[2]/div[8]/div[1]/div/div/div[1]/div/div/div/table/tbody/tr[2]/td[11]/div").text

    # 转为int 删除
    WKFC = int(WKFC.replace(",", ''))

    # 判断第一行JUNCEO
    if WKFC >= 100:

        #  拿到VSFC列的第一个数据
        VSFC_T6 = driver.find_element_by_xpath(
            "/html/body/div[1]/div[2]/div[8]/div[1]/div/div/div[1]/div/div/"
            "div/table/tbody/tr[2]/td[12]/div/table/tbody/tr/td/div").text

        # str删除最后一个字符
        VSFC_T6 = VSFC_T6[:-1]

        # 拿到VSFC第一行name
        VSFC_name = driver.find_element_by_xpath(
            "/html/body/div[1]/div[2]/div[8]/div[1]/div/div/div[1]/div/div/div/table/tbody/tr[2]/td[2]/div").text

        # 添加到字典，去除%
        for r in VSFC_T6.split("%"):
            VSFC_dic[VSFC_name] = int(r)

    else:
        # print("WKFC小于100，不得把数据添加到字典")
        pass
    # 循环所有数据VSFC列
    for VSFC_all in range(3, 25):

        # 遍历WKFC_All每一个数据
        WKFC_All = driver.find_element_by_xpath(
            "/html/body/div[1]/div[2]/div[8]/div[1]/div/div/div[1]/div/div/div/table/tbody/tr[%s]/td[10]/div" % VSFC_all).text

        # WKFC_All转为int删除 ,
        WKFC_All = int(WKFC_All.replace(",", ''))

        if WKFC_All >= 100:

            # 遍历每一个数据
            VSFC_AllXpath = driver.find_element_by_xpath(
                "/html/body/div[1]/div[2]/div[8]/div[1]/div/div/div[1]/div/div/"
                "div/table/tbody/tr[%s]/td[11]/div/table/tbody/tr/td/div" % VSFC_all).text

            #  遍历每一个数据,str删除最后一个字符
            VSFC_AllXpath = VSFC_AllXpath[:-1]

            # 遍历每一个name
            VSFC_Allname = driver.find_element_by_xpath(
                "/html/body/div[1]/div[2]/div[8]/div[1]/div/div/div[1]/div/div/div/table/tbody/tr[%s]/td[1]/div" % VSFC_all).text

            # 添加到字典,去除%
            for VSFC_split in VSFC_AllXpath.split("%"):
                VSFC_dic[VSFC_Allname] = int(VSFC_split)

    # VSFC_sort排序
    VSFC_sort = sorted(VSFC_dic.items(), key=lambda x: x[1], reverse=False)

    # 判断VSFC_sort字典中value是否有0，有则删除。
    # for value2 in list(VSFC_dic.values()):
    #     if value2 == 0:
    #         del VSFC_sort[value2]
    # print(VSFC_sort)

    # VSFC:最小的3个元素
    # print(f'VSFC:最小的3个元素：{VSFC_sort[:3]}')

    # 对最小的3个元素，转换输出样式
    Minimum2 = '%s %s%%, %s %s%%, %s %s%%' % (
        VSFC_sort[0][0], VSFC_sort[0][1], VSFC_sort[1][0], VSFC_sort[1][1], VSFC_sort[2][0], VSFC_sort[2][1])
    # print(Minimum2)

    # Bi时间，当前时间 - 1
    Date = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y-%m-%d")

    # 从txt获取DOD
    with open(r'C:\PythonProject\CESBG-BCC\text\%s_dod.txt' % Date) as f:
        read_data = f.read()
        a = read_data.split()
        # print(a[-3])

    # dong tai zhu ti
    now = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime('%Y%m%d')

    year = (datetime.datetime.now() - datetime.timedelta(days=1)).year
    month = (datetime.datetime.now() - datetime.timedelta(days=1)).month
    ls = [str(year), str(month), '20']
    str_join = ''.join(ls)

    day = calendar.monthrange(year, month)[1]
    if len(str(month)) == 1:
        month = '0' + str(month)
    Lastday = str(year) + str(month) + str(day)

    gist1 = 'Up to %s Billing %sM, VS.CEO target Hit rate %s, VS.F/C Hit rate %s, DOD %sM.  F/C hit lower VS.CEO:%s； VS.F/C:%s.' % (
        Date, T1, T2, T3, a[-3], Minimum, Minimum2)
    gist2 = 'Up to %s Billing %sM, VS.CEO target Hit rate %s, VS.F/C Hit rate %s, DOD %sM.' % (
    Date, T1, T2, T3, a[-3])


    # data , Minimum, Minimum2    F/C hit lower VS.CEO:%s； VS.F/C:%s.
    # gist = 'Up to %s Billing %sM, VS.CEO target Hit rate %s, VS.F/C Hit rate %s, DOD %sM.  F/C hit lower VS.CEO:%s； VS.F/C:%s.' \
    #        % (Date, T1, T2, T3, a[-3], Minimum, Minimum2)

    # 写入文件
    file_handle = open(r'C:\PythonProject\CESBG-BCC\text\%s.txt' % Date, mode='w')
    if now >= str_join <= Lastday:
        file_handle.write(gist1)
    else:
        file_handle.write(gist2)
    file_handle.close()
    mylogger.info('Y_text')

    # 退出浏览器
    driver.quit()

    im = Image.open(r"C:\Users\Administrator\Desktop\BI.png")
    imSet = im.resize((1280, 3200))
    imSet.save(r"C:\Users\Administrator\Pictures\BiPng\%s.png" % Date)
    sleep(1)

    os.remove(r'C:\Users\Administrator\Desktop\BI.png')
    os.remove(r"C:\PythonProject\CESBG-BCC\text\%s_dod.txt" % Date)


CESBGRevenueReport()
