from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains

WAIT_SECONDS_LIMIT = 60

#option設定用意問一下耀宗
driver = webdriver.Chrome()
url = 'http://fbcbi.efoxconn.com/decision/view/report?viewlet=%252FRevenue_PRD%252FRevenue_Reports_BG.frm&__parameters__=%257B%2522__pi__%2522%253Atrue%257D&_=1598067216116'
driver.get(url)
dod = WebDriverWait(driver, WAIT_SECONDS_LIMIT).until(
                EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div[2]/div[9]/div[1]/div/div/div[1]/div/div/div/table/tbody')))
dod_text = dod.text
pass