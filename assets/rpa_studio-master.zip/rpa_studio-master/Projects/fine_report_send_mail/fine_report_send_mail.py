from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from Functions.DB import *
from Functions.Email import *
from Functions.Log import *
from Setting import *
import socket
from datetime import date, datetime, timedelta

WAIT_SECONDS_LIMIT = 60
NORMAL_RETRY_TIMES = 6
PROCESS_NAME = 'Fine Report Send Mail'
MAIL_NAME_COLUMN_NAME = 'MAIL_NAME'
MAIL_SUBJECT_COLUMN_NAME = 'MAIL_SUBJECT'
RESULT_CESBG_MAIL_NAME = 'CESBG'
RESULT_EPBG_MAIL_NAME = 'EPBG'
RESULT_FIDM_MAIL_NAME = 'FIDM'
RESULT_CPB_MAIL_NAME = 'CPB'
RESULT_EXCEPTION_MAIL_NAME = 'EXCEPTION_MAIL'
MAIL_RECIPIENT_TYPE_COLUMN_NAME = 'MAIL_RECIPIENT_TYPE'
USER_EMAIL_ADDRESS_COLUMN_NAME = 'USER_EMAIL_ADDRESS'

CESBG_REPORT_NAME = 'cesbg'
EPBG_REPORT_NAME = 'epbg'
FIDM_REPORT_NAME = 'fidm'
CPB_REPORT_NAME = 'cpb'
TOTAL_AMOUNT_NAME = 'TOTALAMOUNT'
CEORATE_NAME = 'CEORATE'
FCRATE_NAME = 'FCRATE'
DOD_NAME = 'DOD'

class Mail():
    name = ''
    url = ''  # 要截圖的url
    mail_content_name = ''  # 在mail裡附上的報表名稱
    subject = ''
    mail_to_list = []  # 收件者
    mail_cc_list = []  # cc
    mail_bcc_list = []  # 密件副本
    def __init__(self,
                 name,
                 url,
                 mail_content_name,
                 subject,
                 mail_to_list,
                 mail_cc_list,
                 mail_bcc_list):
        self.name = name
        self.url = url
        self.mail_content_name = mail_content_name
        self.subject = subject
        self.mail_to_list = mail_to_list
        self.mail_cc_list = mail_cc_list
        self.mail_bcc_list = mail_bcc_list
def get_report_value(report_name,column_name):
    value = []
    # region sql setting
    if report_name == CESBG_REPORT_NAME:
        if column_name == DOD_NAME:
            sql = """SELECT round((REVLAST-REVLASTLAST)/1000000) AS DOD 
                                    FROM (
                                        SELECT IDYEAR,IDMONTH,
                                               MAX(CASE WHEN  POSTINGDATE= to_char(SYSDATE-1,'yyyy-MM-dd') THEN totalALCA END ) AS REVLAST,
                                               MAX(CASE WHEN  POSTINGDATE= to_char(SYSDATE-2,'yyyy-MM-dd') THEN totalALCA END ) AS REVLASTLAST
                                        FROM (
                                            SELECT bill.IDYear,bill.IDMonth ,
                                                    bill.PostingDate , 
                                                    sum(AmountInLCAccumlate)  as totalALCA
                                            FROM DR_Analysis_BillingDocument bill                      
                                            WHERE  bill.IsReceivable =1
                                                    AND bill.IDYear=to_char(sysdate-1,'yyyy')
                                                    AND bill.IDMonth=to_char(sysdate-1,'fmMM')
                                                    AND TO_NUMBER(sysdate-to_date(bill.PostingDate,'yyyy-mm-dd,hh24:mi:ss'))<3
                                                    AND bill.PostingDate < to_char(sysdate,'yyyy-MM-dd')  
                                            GROUP BY  bill.IDYear,bill.IDMonth ,bill.PostingDate 
                                            order by bill.PostingDate 
                                        )GROUP BY IDYEAR,IDMONTH
                                    )"""
        else:
            sql = """SELECT ROUND(E.totalAmount/1000000) AS TOTALAMOUNT,(E.totalAmount/D.totalCEOTarget)*100 as CEORate, (E.totalAmount/D.totalFC)*100 as FCRate
                    FROM
                            (SELECT SUM(CEOTarget) as totalCEOTarget, SUM(Forcast) as totalFC, to_char(sysdate-1,'yyyy') as pkey
                                    FROM DR_IMPORT_BUCUSTOMERFCCEO_SITE
                                    where  delflag ='false' and to_char(UptoDay,'yyyy-MM')= to_char(SYSDATE-1,'yyyy-MM')
                                        and BUCode!='all'
                            ) D,
                            (SELECT to_char(sysdate-1,'yyyy') as pkey,nvl(SUM(roll.AmountInLCSummary),0) as totalAmount
                                    FROM DR_Analysis_BillingDocument roll
                                    WHERE  IsReceivable=1
                                         and IDYear=to_char(SYSDATE-1,'yyyy') and IDMonth=to_char(SYSDATE-1,'MM')
                                             AND to_char(to_date(roll.PostingDate,'yyyy-mm-dd,hh24:mi:ss'),'DDD')<=to_char(sysdate-1,'DDD')
                            ) E
                    WHERE D.pkey=E.pkey"""
    elif report_name == EPBG_REPORT_NAME:
        if column_name == DOD_NAME:
            sql = """SELECT 	round((REVLAST-REVLASTLAST)/1000000) AS DOD 
                        FROM (
                            SELECT IDYEAR,IDMONTH,
                                   MAX(CASE WHEN  dateitem= to_char(SYSDATE-1,'yyyy-MM-dd') THEN totalALCA END ) AS REVLAST,
                                   MAX(CASE WHEN  dateitem= to_char(SYSDATE-2,'yyyy-MM-dd') THEN totalALCA END ) AS REVLASTLAST
                            FROM (
                                SELECT S1.IDYear,S1.IDMonth,
                                        S1.dateItem ,
                                        nvl(S1.sbg,'Others') as sbg,
                                        sum(S1.AmountInLCAccumlate)  as totalALCA
                                 FROM (
                                         SELECT bill.IDYear,bill.IDMonth,bill.PostingDate as dateItem,nvl(aba.sbg,'Others') as sbg,bill.AmountInLCAccumlate ,
                                                bill.AmountInLCSummary ,nvl(aba.ENDCUSTOMERname ,'Others') AS ENDCUSTOMERname
                                         FROM DR_Analysis_BillingDocument bill 
                                         left JOIN 
                                         (select distinct profitcenter,sbg,CUSTOMERCODE,ENDCUSTOMERname from base_buendcustomerprofitall where delflag='false') aba
                                         ON bill.profitcenter=aba.profitcenter AND bill.CUSTOMERCODE = aba.CUSTOMERCODE AND bill.ENDCUSTOMER=aba.ENDCUSTOMERname   
                                         WHERE bill.IsReceivable =1 AND bill.IDYear=to_char(sysdate-1,'yyyy') AND bill.IDMonth=to_char(sysdate-1,'fmMM')
                                               AND TO_NUMBER(sysdate-to_date(bill.PostingDate,'yyyy-mm-dd,hh24:mi:ss'))<3 
                                        ) S1
                                WHERE S1.SBG='EPBG'
                                GROUP BY  S1.IDYear,S1.IDMonth ,S1.dateItem,S1.sbg
                                ORDER BY S1.dateItem
                            )WHERE dateitem IN (to_char(sysdate-1,'yyyy-MM-dd'),to_char(sysdate-2,'yyyy-MM-dd'))
                            GROUP BY IDYEAR,IDMONTH
                        )"""
        else:
            sql = """SELECT
                        ROUND(E.totalAmount/1000000) as totalamount,
                        (E.totalAmount / D.totalCEOTarget)* 100 AS CEORate,
                        (E.totalAmount / D.totalFC)* 100 AS FCRate
                    FROM
                        (
                            SELECT SUM(CEOTarget) AS totalCEOTarget ,
                                SUM(Forcast) AS totalFC,
                                TO_CHAR(SYSDATE-1, 'yyyy') AS pkey
                            FROM
                                DR_IMPORT_BUCUSTOMERFCCEO_SITE ac ,
                                (
                                    SELECT DISTINCT bucode,endcustomername
                                FROM
                                    base_buendcustomerprofitall
                                WHERE
                                    delflag = 'false'
                                    AND SBG = 'EPBG') ab
                            WHERE
                                ac.delflag = 'false'
                                AND TO_CHAR(ac.UptoDay, 'yyyy-MM')= to_char(SYSDATE-1,'yyyy-MM')
                                AND ac.BUCode != 'all'
                                AND ac.BUCode=ab.bucode AND ac.ENDCUSTOMERNAME=ab.endcustomername
                        ) D,
                        (
                            SELECT TO_CHAR(SYSDATE-1, 'yyyy') AS pkey,
                                NVL(sum(aba.AmountInLCAccumlate), 0) AS totalAmount
                            FROM(
                                 SELECT bill.IDYear,bill.IDMonth,
                                                    bill.PostingDate as dateItem,
                                                    nvl(aba.sbg,'Others') as sbg,
                                                     bill.AmountInLCAccumlate 
                                                    ,nvl(aba.ENDCUSTOMERname ,'Others') AS ENDCUSTOMERname
                                   FROM DR_Analysis_BillingDocument bill left JOIN 
                                    (select distinct profitcenter,sbg,CUSTOMERCODE,ENDCUSTOMERname from base_buendcustomerprofitall where delflag='false') aba
                                    ON bill.profitcenter=aba.profitcenter
                                        AND bill.CUSTOMERCODE = aba.CUSTOMERCODE
                                        AND bill.ENDCUSTOMER=aba.ENDCUSTOMERname   
                                    WHERE bill.IsReceivable =1
                                          AND bill.PostingDate=TO_CHAR(SYSDATE-1,'yyyy-mm-dd')
                                ) aba
                            WHERE
                                aba.SBG = 'EPBG'
                        ) E
                    WHERE
                        D.pkey = E.pkey"""
    elif report_name == FIDM_REPORT_NAME:
        if column_name == DOD_NAME:
            sql = """SELECT 	round((REVLAST-REVLASTLAST)/1000000) AS DOD 
                        FROM (
                            SELECT IDYEAR,IDMONTH,
                                   MAX(CASE WHEN  dateitem= to_char(SYSDATE-1,'yyyy-MM-dd') THEN totalALCA END ) AS REVLAST,
                                   MAX(CASE WHEN  dateitem= to_char(SYSDATE-2,'yyyy-MM-dd') THEN totalALCA END ) AS REVLASTLAST
                            FROM (
                                SELECT S1.IDYear,S1.IDMonth,
                                        S1.dateItem ,
                                        nvl(S1.sbg,'Others') as sbg,
                                        sum(S1.AmountInLCAccumlate)  as totalALCA
                                 FROM (
                                         SELECT bill.IDYear,bill.IDMonth,bill.PostingDate as dateItem,nvl(aba.sbg,'Others') as sbg,bill.AmountInLCAccumlate ,
                                                bill.AmountInLCSummary ,nvl(aba.ENDCUSTOMERname ,'Others') AS ENDCUSTOMERname
                                         FROM DR_Analysis_BillingDocument bill 
                                         left JOIN 
                                         (select distinct profitcenter,sbg,CUSTOMERCODE,ENDCUSTOMERname from base_buendcustomerprofitall where delflag='false') aba
                                         ON bill.profitcenter=aba.profitcenter AND bill.CUSTOMERCODE = aba.CUSTOMERCODE AND bill.ENDCUSTOMER=aba.ENDCUSTOMERname   
                                         WHERE bill.IsReceivable =1 AND bill.IDYear=to_char(sysdate-1,'yyyy') AND bill.IDMonth=to_char(sysdate-1,'fmMM')
                                               AND TO_NUMBER(sysdate-to_date(bill.PostingDate,'yyyy-mm-dd,hh24:mi:ss'))<3 
                                        ) S1
                                WHERE S1.SBG='FIDM'
                                GROUP BY  S1.IDYear,S1.IDMonth ,S1.dateItem,S1.sbg
                                ORDER BY S1.dateItem
                            )WHERE dateitem IN (to_char(sysdate-1,'yyyy-MM-dd'),to_char(sysdate-2,'yyyy-MM-dd'))
                            GROUP BY IDYEAR,IDMONTH
                        )"""
        else:
            sql = """SELECT
                            ROUND(E.totalAmount/1000000) as totalamount,
                            (E.totalAmount / D.totalCEOTarget)* 100 AS CEORate,
                            (E.totalAmount / D.totalFC)* 100 AS FCRate
                        FROM
                            (
                                SELECT SUM(CEOTarget) AS totalCEOTarget ,
                                    SUM(Forcast) AS totalFC,
                                    TO_CHAR(SYSDATE-1, 'yyyy') AS pkey
                                FROM
                                    DR_IMPORT_BUCUSTOMERFCCEO_SITE ac ,
                                    (
                                        SELECT DISTINCT bucode,endcustomername
                                    FROM
                                        base_buendcustomerprofitall
                                    WHERE
                                        delflag = 'false'
                                        AND SBG = 'FIDM') ab
                                WHERE
                                    ac.delflag = 'false'
                                    AND TO_CHAR(ac.UptoDay, 'yyyy-MM')= to_char(SYSDATE-1,'yyyy-MM')
                                    AND ac.BUCode != 'all'
                                    AND ac.BUCode=ab.bucode AND ac.ENDCUSTOMERNAME=ab.endcustomername
                            ) D,
                            (
                                SELECT TO_CHAR(SYSDATE-1, 'yyyy') AS pkey,
                                    NVL(sum(aba.AmountInLCAccumlate), 0) AS totalAmount
                                FROM(
                                     SELECT bill.IDYear,bill.IDMonth,
                                                        bill.PostingDate as dateItem,
                                                        nvl(aba.sbg,'Others') as sbg,
                                                         bill.AmountInLCAccumlate 
                                                        ,nvl(aba.ENDCUSTOMERname ,'Others') AS ENDCUSTOMERname
                                       FROM DR_Analysis_BillingDocument bill left JOIN 
                                        (select distinct profitcenter,sbg,CUSTOMERCODE,ENDCUSTOMERname from base_buendcustomerprofitall where delflag='false') aba
                                        ON bill.profitcenter=aba.profitcenter
                                            AND bill.CUSTOMERCODE = aba.CUSTOMERCODE
                                            AND bill.ENDCUSTOMER=aba.ENDCUSTOMERname   
                                        WHERE bill.IsReceivable =1
                                              AND bill.PostingDate=TO_CHAR(SYSDATE-1,'yyyy-mm-dd')
                                    ) aba
                                WHERE
                                    aba.SBG = 'FIDM'
                            ) E
                        WHERE
                            D.pkey = E.pkey"""
    elif report_name == CPB_REPORT_NAME:
        if column_name == DOD_NAME:
            sql = """SELECT 	round((REVLAST-REVLASTLAST)/1000000) AS DOD 
                        FROM (
                            SELECT IDYEAR,IDMONTH,
                                       MAX(CASE WHEN  dateitem= to_char(SYSDATE-1,'yyyy-MM-dd') THEN totalALCA END ) AS REVLAST,
                                       MAX(CASE WHEN  dateitem= to_char(SYSDATE-2,'yyyy-MM-dd') THEN totalALCA END ) AS REVLASTLAST
                            FROM (
                                SELECT S1.IDYear,S1.IDMonth,S1.dateItem ,nvl(S1.bucode,'Others') as bucode,sum(S1.AmountInLCAccumlate)  as totalALCA
                                FROM (
                                        SELECT bill.IDYear,bill.IDMonth,bill.PostingDate as dateItem,nvl(aba.bucode,'Others') as bucode,AmountInLCAccumlate,AmountInLCSummary
                                        FROM DR_Analysis_BillingDocument bill LEFT join
                                            (select distinct profitcenter,BUCODE from base_buendcustomerprofitall where delflag='false') aba   
                                        ON bill.profitcenter=aba.profitcenter
                                        WHERE  bill.IsReceivable =1 AND bill.IDYear=to_char(sysdate-1,'yyyy')AND bill.IDMonth=to_char(sysdate-1,'fmMM')
                                               AND TO_NUMBER(sysdate-to_date(bill.PostingDate,'yyyy-mm-dd,hh24:mi:ss'))<3
                                      )S1
                                 WHERE S1.bucode='CPB' AND S1.dateItem IN (to_char(sysdate-1,'yyyy-MM-dd'),to_char(sysdate-2,'yyyy-MM-dd'))
                                 GROUP BY  S1.IDYear,S1.IDMonth ,S1.dateItem,S1.bucode
                                 ORDER BY S1.dateItem 
                            )GROUP BY IDYEAR,IDMONTH
                        )"""
        else:
            sql = """SELECT ROUND(E.totalAmount/1000000) AS totalAmount, (E.totalAmount/CASE WHEN D.totalCEOTarget=0 THEN 1 ELSE D.totalCEOTarget end)*100 as CEORate, 
                        (E.totalAmount/CASE WHEN D.totalFC=0 THEN 1 ELSE D.totalFC end )*100 as FCRate 
                        FROM         
                             (SELECT sum(CEOTarget) as totalCEOTarget ,sum(Forcast) as totalFC,  to_char(sysdate-1,'yyyy') as pkey  
                                from DR_IMPORT_BUCUSTOMERFCCEO_SITE ac ,
                                (select distinct bucode from base_buendcustomerprofitall where delflag='false' AND BUCODE='CPB') ab
                                where ac.delflag='false' and to_char(ac.UptoDay,'yyyy-MM')=to_char(SYSDATE-1,'yyyy-MM')
                                               AND ac.BUCode!='all' and ac.bucode=ab.bucode
                                ) D,
                                (SELECT to_char(sysdate-1,'yyyy') as pkey,nvl(SUM(roll.AmountInLCSummary),0) as totalAmount
                                 FROM DR_Analysis_BillingDocument roll,
                                        (select distinct profitcenter,bucode from base_buendcustomerprofitall where delflag='false' and BUCODE='CPB' ) aba 
                                        WHERE  IsReceivable=1 and IDYear=to_char(SYSDATE-1,'yyyy') and IDMonth=to_char(SYSDATE-1,'MM')
                                                 AND to_char(to_date(roll.PostingDate,'yyyy-mm-dd,hh24:mi:ss'),'DDD')<=to_char(sysdate-1,'DDD')
                                                 and roll.profitcenter=aba.profitcenter
                                ) E 
                        WHERE D.pkey=E.pkey"""
    # endregion
    if column_name == TOTAL_AMOUNT_NAME:
        value = getOracleData(DB_IP,
                                  DB_PORT,
                                  DB_NAME,
                                  DB_USERNAME,
                                  DB_PASSWORD,
                                  sql)[TOTAL_AMOUNT_NAME]
    elif column_name == CEORATE_NAME:
        value = getOracleData(DB_IP,
                              DB_PORT,
                              DB_NAME,
                              DB_USERNAME,
                              DB_PASSWORD,
                              sql)[CEORATE_NAME]
    elif column_name == FCRATE_NAME:
        value = getOracleData(DB_IP,
                              DB_PORT,
                              DB_NAME,
                              DB_USERNAME,
                              DB_PASSWORD,
                              sql)[FCRATE_NAME]
    elif column_name == DOD_NAME:
        value = getOracleData(DB_IP,
                              DB_PORT,
                              DB_NAME,
                              DB_USERNAME,
                              DB_PASSWORD,
                              sql)[DOD_NAME]
    if len(value) != 0:
        value = value[0]
    else:
        value = 0
    return value
# 取得PROCESS_KEY
PROCESS_KEY = int(getOracleData(DB_IP,
                                DB_PORT,
                                DB_NAME,
                                DB_USERNAME,
                                DB_PASSWORD,
                                'SELECT PROCESS_KEY '
                                'FROM REVENUE.RPA_DT_PROCESS '
                                "WHERE PROCESS_NAME = '" + str(PROCESS_NAME) + "'")['PROCESS_KEY'][0])

# region 取得mail list
mail_list = getOracleData(DB_IP,
                          DB_PORT,
                          DB_NAME,
                          DB_USERNAME,
                          DB_PASSWORD,
                          'SELECT * '
                          'FROM REVENUE.RPA_DT_MAIL_LIST_V '
                          'WHERE PROCESS_KEY = ' + str(PROCESS_KEY))
# region cesbg property setting
cesbg_mail = mail_list[mail_list[MAIL_NAME_COLUMN_NAME] == RESULT_CESBG_MAIL_NAME]
cesbg_mail = cesbg_mail.reset_index(drop=True)
cesbg_mail_to_list = cesbg_mail[cesbg_mail[MAIL_RECIPIENT_TYPE_COLUMN_NAME] == MAIL_RECIPIENT_TYPE_TO_KEY][USER_EMAIL_ADDRESS_COLUMN_NAME].to_list()
cesbg_mail_cc_list = cesbg_mail[cesbg_mail[MAIL_RECIPIENT_TYPE_COLUMN_NAME] == MAIL_RECIPIENT_TYPE_CC_KEY][USER_EMAIL_ADDRESS_COLUMN_NAME].to_list()
cesbg_mail_bcc_list = cesbg_mail[cesbg_mail[MAIL_RECIPIENT_TYPE_COLUMN_NAME] == MAIL_RECIPIENT_TYPE_BCC_KEY][USER_EMAIL_ADDRESS_COLUMN_NAME].to_list()
cesbg_total_amount = f'{get_report_value(CESBG_REPORT_NAME, TOTAL_AMOUNT_NAME):,}'
cesbg_ceo_rate = round(get_report_value(CESBG_REPORT_NAME, CEORATE_NAME), 2)
cesbg_fcrate = round(get_report_value(CESBG_REPORT_NAME, FCRATE_NAME), 2)
cesbg_dod = f'{get_report_value(CESBG_REPORT_NAME, DOD_NAME):,}'
yesterday = (date.today() - timedelta(days=1)).strftime('%Y-%m-%d')
# Up to 2021-01-04 Billing 3,048M, VS.CEO target Hit rate 5.47%, VS.F/C Hit rate 4.92%, DOD 2,044M.
cesbg_subject = 'Up to {0} Billing {1}M, VS.CEO target Hit rate {2}%, VS.F/C Hit rate {3}%, DOD {4}M.'.format(
    yesterday,
    cesbg_total_amount,
    cesbg_ceo_rate,
    cesbg_fcrate,
    cesbg_dod)
# endregion
# region epbg property setting
epbg_mail = mail_list[mail_list[MAIL_NAME_COLUMN_NAME] == RESULT_EPBG_MAIL_NAME]
epbg_mail = epbg_mail.reset_index(drop=True)
epbg_mail_to_list = epbg_mail[epbg_mail[MAIL_RECIPIENT_TYPE_COLUMN_NAME] == MAIL_RECIPIENT_TYPE_TO_KEY][USER_EMAIL_ADDRESS_COLUMN_NAME].to_list()
epbg_mail_cc_list = epbg_mail[epbg_mail[MAIL_RECIPIENT_TYPE_COLUMN_NAME] == MAIL_RECIPIENT_TYPE_CC_KEY][USER_EMAIL_ADDRESS_COLUMN_NAME].to_list()
epbg_mail_bcc_list = epbg_mail[epbg_mail[MAIL_RECIPIENT_TYPE_COLUMN_NAME] == MAIL_RECIPIENT_TYPE_BCC_KEY][USER_EMAIL_ADDRESS_COLUMN_NAME].to_list()
epbg_total_amount = f'{get_report_value(EPBG_REPORT_NAME, TOTAL_AMOUNT_NAME):,}'
epbg_ceo_rate = round(get_report_value(EPBG_REPORT_NAME, CEORATE_NAME), 2)
epbg_fcrate = round(get_report_value(EPBG_REPORT_NAME, FCRATE_NAME), 2)
epbg_dod = f'{get_report_value(EPBG_REPORT_NAME, DOD_NAME):,}'
# Up to 2021-01-03 EPBG Billing 28 M, VS.CEO target Hit rate 0.16%, VS.F/C Hit rate 0.17%, DOD 0M.
epbg_subject = 'Up to {0} EPBG Billing {1}M, VS.CEO target Hit rate {2}%, VS.F/C Hit rate {3}%, DOD {4}M.'.format(
    yesterday,
    epbg_total_amount,
    epbg_ceo_rate,
    epbg_fcrate,
    epbg_dod)
# endregion
# region fidm property setting
fidm_mail = mail_list[mail_list[MAIL_NAME_COLUMN_NAME] == RESULT_FIDM_MAIL_NAME]
fidm_mail = fidm_mail.reset_index(drop=True)
fidm_mail_to_list = fidm_mail[fidm_mail[MAIL_RECIPIENT_TYPE_COLUMN_NAME] == MAIL_RECIPIENT_TYPE_TO_KEY][USER_EMAIL_ADDRESS_COLUMN_NAME].to_list()
fidm_mail_cc_list = fidm_mail[fidm_mail[MAIL_RECIPIENT_TYPE_COLUMN_NAME] == MAIL_RECIPIENT_TYPE_CC_KEY][USER_EMAIL_ADDRESS_COLUMN_NAME].to_list()
fidm_mail_bcc_list = fidm_mail[fidm_mail[MAIL_RECIPIENT_TYPE_COLUMN_NAME] == MAIL_RECIPIENT_TYPE_BCC_KEY][USER_EMAIL_ADDRESS_COLUMN_NAME].to_list()
fidm_total_amount = f'{get_report_value(FIDM_REPORT_NAME, TOTAL_AMOUNT_NAME):,}'
fidm_ceo_rate = round(get_report_value(FIDM_REPORT_NAME, CEORATE_NAME), 2)
fidm_fcrate = round(get_report_value(FIDM_REPORT_NAME, FCRATE_NAME), 2)
fidm_dod = f'{get_report_value(FIDM_REPORT_NAME, DOD_NAME):,}'
# Up to 2021-01-04 FIDM Billing 372M, VS.CEO target Hit rate 2.56%, VS.F/C Hit rate 1.59%, DOD 372M.
fidm_subject = 'Up to {0} FIDM Billing {1}M, VS.CEO target Hit rate {2}%, VS.F/C Hit rate {3}%, DOD {4}M.'.format(
    yesterday,
    fidm_total_amount,
    fidm_ceo_rate,
    fidm_fcrate,
    fidm_dod)
# endregion
# region cpb property setting
cpb_mail = mail_list[mail_list[MAIL_NAME_COLUMN_NAME] == RESULT_CPB_MAIL_NAME]
cpb_mail = cpb_mail.reset_index(drop=True)
cpb_mail_to_list = cpb_mail[cpb_mail[MAIL_RECIPIENT_TYPE_COLUMN_NAME] == MAIL_RECIPIENT_TYPE_TO_KEY][USER_EMAIL_ADDRESS_COLUMN_NAME].to_list()
cpb_mail_cc_list = cpb_mail[cpb_mail[MAIL_RECIPIENT_TYPE_COLUMN_NAME] == MAIL_RECIPIENT_TYPE_CC_KEY][USER_EMAIL_ADDRESS_COLUMN_NAME].to_list()
cpb_mail_bcc_list = cpb_mail[cpb_mail[MAIL_RECIPIENT_TYPE_COLUMN_NAME] == MAIL_RECIPIENT_TYPE_BCC_KEY][USER_EMAIL_ADDRESS_COLUMN_NAME].to_list()
cpb_total_amount = f'{get_report_value(CPB_REPORT_NAME, TOTAL_AMOUNT_NAME):,}'
cpb_ceo_rate = round(get_report_value(CPB_REPORT_NAME, CEORATE_NAME), 2)
cpb_fcrate = round(get_report_value(CPB_REPORT_NAME, FCRATE_NAME), 2)
cpb_dod = f'{get_report_value(CPB_REPORT_NAME, DOD_NAME):,}'
# Up to 2021-01-04 CPB Billing 343M, VS.CEO target Hit rate 10.34%, VS.F/C Hit rate 10.34%, DOD 343M.
cpb_subject = 'Up to {0} CPB Billing {1}M, VS.CEO target Hit rate {2}%, VS.F/C Hit rate {3}%, DOD {4}M.'.format(
    yesterday,
    cpb_total_amount,
    cpb_ceo_rate,
    cpb_fcrate,
    cpb_dod)
# endregion
# region mail_objs list creation
cesbg_obj = Mail(name='cesbg',
                 url='http://fbcbi.efoxconn.com/decision/view/report?viewlet=%252FRevenue_PRD%252FRevenue_Reports_BG.frm&__parameters__=%257B%2522__pi__%2522%253Atrue%257D&_=1598067216116',
                 mail_content_name='CESBG global daily revenue report',
                 subject=cesbg_subject,
                 mail_to_list=cesbg_mail_to_list,
                 mail_cc_list=cesbg_mail_cc_list,
                 mail_bcc_list=cesbg_mail_bcc_list
                 )
epbg_obj = Mail(name='epbg',
                 url='http://fbcbi.efoxconn.com/decision/view/form?viewlet=%252FRevenue_PRD%252FRevenue_Reports_SBG_EPBG.frm&__parameters__=%257B%2522__pi__%2522%253Atrue%252C%2522%2524SBG%2522%253A%2522%2524%2524%2524%2522%257D&_=1597837926373',
                 mail_content_name='EPBG daily revenue report',
                 subject=epbg_subject,
                 mail_to_list=epbg_mail_to_list,
                 mail_cc_list=epbg_mail_cc_list,
                 mail_bcc_list=epbg_mail_bcc_list
                 )
fidm_obj = Mail(name='fidm',
                 url='http://fbcbi.efoxconn.com/decision/view/report?viewlet=%252FRevenue_PRD%252FRevenue_Reports_SBG_FIDM.frm&__parameters__=%257B%2522__pi__%2522%253Atrue%252C%2522%2524SBG%2522%253A%2522%2524%2524%2524%2522%257D&_=1600147537974',
                 mail_content_name='FIDM daily revenue report',
                 subject=fidm_subject,
                 mail_to_list=fidm_mail_to_list,
                 mail_cc_list=fidm_mail_cc_list,
                 mail_bcc_list=fidm_mail_bcc_list
                 )
cpb_obj = Mail(name='cpb',
                 url='http://fbcbi.efoxconn.com/decision/view/report?viewlet=%252FRevenue_PRD%252FRevenue_Reports_BU_SITE.frm&__parameters__=%257B%2522__pi__%2522%253Atrue%252C%2522BU%2522%253A%2522CPB%2522%257D&_=1600151321302',
                 mail_content_name='CPB daily revenue report',
                 subject=cpb_subject,
                 mail_to_list=cpb_mail_to_list,
                 mail_cc_list=cpb_mail_cc_list,
                 mail_bcc_list=cpb_mail_bcc_list
                 )
mail_objs = []
mail_objs.append(cesbg_obj)
mail_objs.append(epbg_obj)
mail_objs.append(fidm_obj)
mail_objs.append(cpb_obj)
# endregion
for mail_obj in mail_objs:
    retry_times = NORMAL_RETRY_TIMES
    while retry_times > 0:
        try:
            sub_seq_key = selectSeq(DB_IP, DB_PORT, DB_NAME, DB_USERNAME, DB_PASSWORD,
                                    'REVENUE.RPA_DT_SUB_SEQ_KEY_S')
            CURRENT_SEVER_NAME = socket.gethostname()
            insertToLog(ip=DB_IP,
                        port=DB_PORT,
                        DBname=DB_NAME,
                        userName=DB_USERNAME,
                        password=DB_PASSWORD,
                        sub_seq_key=sub_seq_key,
                        process_key=PROCESS_KEY,
                        log_type_key=LOG_TYPE_LOG_KEY,
                        log_name=mail_obj.name + ' Process Start',
                        log_result=LOG_RESULT_SUCCESS,
                        log_message=mail_obj.name + ' Process Start',
                        log_user='',
                        last_updated_by='rpa',
                        run_at_server_name=CURRENT_SEVER_NAME
                        )
            target_url = mail_obj.url
            # region 截圖
            option = webdriver.ChromeOptions()
            option.add_argument('--headless')
            driver = webdriver.Chrome(options=option)
            driver.set_window_position(0, 0)
            driver.get(target_url)
            WebDriverWait(driver, 60).until(EC.visibility_of_element_located((By.ID, 'REPORT1')))
            driver.set_window_size(1920, 1080)
            scroll_height = driver.execute_script(
                'return document.querySelector("body > div.content-container.fr-quick-border-layout.ui-state-enabled > div.fr-quick-adaptive-layout.ui-state-enabled").scrollHeight')
            driver.set_window_size(1920, scroll_height)
            now = datetime.now().strftime('%Y%m%d_%H%M%S')
            image_name_with_ext = '{0}_{1}.png'.format(mail_obj.name, now)
            image_name = '{0}_{1}'.format(mail_obj.name, now)
            image_path = 'images\\' + image_name_with_ext
            driver.save_screenshot(image_path)
            # endregion
            # region 寄信
            mail_content = """<p style="font-size:14px">
                                Dear Sirs:
                              </p>
                              <p style="font-size:14px">
                                {0} is as follows, 
                                please log in to the website: http://fbcbi.efoxconn.com/ 
                                for detail information.
                              </p>
                              <p style="font-size:14px">
                              (It is recommended to sign in with Google Chrome.)
                              </p>
                           """.format(mail_obj.mail_content_name)
            # 添加image到content html
            mail_content += '<img src="cid:' + image_name + '"><br>'
            # 加上圖片之後的字
            mail_content += """<p style="font-size:14px">
                               If there are related issues, please contact cesbg-cm-tj01@mail.foxconn.com
                               </p>
                               <p style="font-size:14px">
                               Note: This is an email from the system, please do not reply directly!
                               </p>
                            """
            # region 加入圖片至msgImage_list
            msgImage_list = []
            fp = open(image_path, 'rb')
            msgImage = MIMEImage(fp.read())
            fp.close()
            msgImage.add_header('Content-ID', '<' + image_name + '>')
            msgImage_list.append(msgImage)
            # endregion
            send_email_by_smtp(smtp_ip=SMTP_IP,
                               smtp_port=SMTP_PORT,
                               email_from=EMAIL_FROM,
                               password=EMAIL_PASSWORD,
                               to=mail_obj.mail_to_list, cc=mail_obj.mail_cc_list, bcc=mail_obj.mail_bcc_list,
                               subject=mail_obj.subject,
                               content_type=SMTP_CONTENT_TYPE_HTML,
                               content=mail_content,
                               images_in_content=msgImage_list,
                               attached_files=[])
            # endregion
            insertToLog(ip=DB_IP,
                        port=DB_PORT,
                        DBname=DB_NAME,
                        userName=DB_USERNAME,
                        password=DB_PASSWORD,
                        sub_seq_key=sub_seq_key,
                        process_key=PROCESS_KEY,
                        log_type_key=LOG_TYPE_LOG_KEY,
                        log_name=mail_obj.name + ' Process End',
                        log_result=LOG_RESULT_SUCCESS,
                        log_message=mail_obj.name + ' Process End',
                        log_user='',
                        last_updated_by='rpa',
                        run_at_server_name=CURRENT_SEVER_NAME
                        )
            driver.quit()
            break  # 成功執行完成，退出while
        except Exception as e:
            now = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
            exception_mail_subject = str(getOracleData(DB_IP,
                                                  DB_PORT,
                                                  DB_NAME,
                                                  DB_USERNAME,
                                                  DB_PASSWORD,
                                                  """
                                                  SELECT MAIL_SUBJECT
                                                  FROM REVENUE.RPA_DT_MAIL
                                                  WHERE PROCESS_KEY = {0}
                                                  AND MAIL_NAME = '{1}'
                                                  """.format(str(PROCESS_KEY),
                                                             RESULT_EXCEPTION_MAIL_NAME))[MAIL_SUBJECT_COLUMN_NAME][0])
            error_text = get_exception_message()
            error_mail = mail_list[mail_list[MAIL_NAME_COLUMN_NAME] == RESULT_EXCEPTION_MAIL_NAME]
            error_mail = error_mail.reset_index(drop=True)
            error_mail_to_list = error_mail[error_mail[MAIL_RECIPIENT_TYPE_COLUMN_NAME] == MAIL_RECIPIENT_TYPE_TO_KEY][
                USER_EMAIL_ADDRESS_COLUMN_NAME].to_list()
            error_mail_cc_list = error_mail[error_mail[MAIL_RECIPIENT_TYPE_COLUMN_NAME] == MAIL_RECIPIENT_TYPE_CC_KEY][
                USER_EMAIL_ADDRESS_COLUMN_NAME].to_list()
            error_mail_bcc_list = error_mail[error_mail[MAIL_RECIPIENT_TYPE_COLUMN_NAME] == MAIL_RECIPIENT_TYPE_BCC_KEY][
                USER_EMAIL_ADDRESS_COLUMN_NAME].to_list()
            retry_times -= 1
            print('retry_times = ' + str(retry_times))
            print(e)
            insertToLog(ip=DB_IP,
                        port=DB_PORT,
                        DBname=DB_NAME,
                        userName=DB_USERNAME,
                        password=DB_PASSWORD,
                        sub_seq_key=sub_seq_key,
                        process_key=PROCESS_KEY,
                        log_type_key=LOG_TYPE_EXCEPTION_KEY,
                        log_name='Raise an error',
                        log_result=LOG_RESULT_FAIL,
                        log_message='{}'.format(error_text),
                        log_user='',
                        last_updated_by='rpa',
                        run_at_server_name=CURRENT_SEVER_NAME
                        )
            send_email_by_smtp(smtp_ip=SMTP_IP,
                               smtp_port=SMTP_PORT,
                               email_from=EMAIL_FROM,
                               password=EMAIL_PASSWORD,
                               to=error_mail_to_list, cc=error_mail_cc_list, bcc=error_mail_bcc_list,
                               subject=exception_mail_subject,
                               content_type=SMTP_CONTENT_TYPE_HTML,
                               # content='sub_seq_key:'+str(sub_seq_key)+' error message:'+error_text,
                               # content='test',
                               content="""
                                        <p style="font-size:14px">
                                        sub_seq_key:{0}
                                        </p>
                                        <p style="font-size:14px">
                                        error message:{1}
                                        </p>
                                       """.format(str(sub_seq_key),error_text),
                               images_in_content=[],
                               attached_files=[])
            try:
                driver.title  # 測試driver是否存在（是否沒有quit）
                driver.quit()
            except:
                pass